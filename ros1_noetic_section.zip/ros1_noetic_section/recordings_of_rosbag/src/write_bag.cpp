#include "ros/ros.h"
#include "rosbag/bag.h"
#include "std_msgs/String.h"


int main(int argc, char **argv)//argv[0]是当前文件的储存内容，索引为1
//
{   
    setlocale(LC_ALL,"");
    char *bag_path=argv[1];
    ros::init(argc,argv,"bag_write");
    ros::NodeHandle nh;
    // 创建bag对象
    rosbag::Bag bag;
    //打开
    bag.open(bag_path,rosbag::BagMode::Write);
    //写
    std_msgs::String msg;
    msg.data = "hello world";
    bag.write("/chatter",ros::Time::now(),msg);
    bag.write("/chatter",ros::Time::now(),msg);
    bag.write("/chatter",ros::Time::now(),msg);
    bag.write("/chatter",ros::Time::now(),msg);
    //关闭
    bag.close();
    // while(ros::ok)
    // {   
    //     char *bag_path=argv[1];
    //     // char one[argc]="";
    //     // for(int i=0;i<argc;i++)
    //     // {
    //     //     one[i]=argv[i];
    //     // }

    //     // for(int i=1;i<argc;i++)
    //     // {
    //     // ROS_INFO("第%d 句，%s",i,argv[i]);
    //     // ROS_INFO("长度 %d\n",i,sizeof(argv[i][]));
    //     // }
    //     ROS_INFO("c%s\n",bag_path);

    // }
    
    return 0;
}
