# robot_simulation说明
![这是图片](pictures/YUANQING.jpg "shinshe")
### 1、本包包含什么捏
    1.1、本包包含的机器人模型
    1.2、gmapping建图仅支持二维雷达
    1.3、二维建图保存与读取
#### 2、使用说明
    2.1、搭载HDL-32三维雷达的麦轮仿真
    2.2、搭载VLP-16三维雷达的麦轮仿真
    2.3、搭载二维雷达的麦轮仿真
#### 3、依赖
#### 4、接口

## 1、本包包含什么捏
该包提供基于物理仿真环境gazebo的机器人仿真及其对应的基于ros话题通讯的接口，同时也提供了rviz可视化界面观察相关传感器信息。
### 1.1、本包包含的机器人模型
四轮麦轮机器人，可搭载二维雷达、三维机械式雷达（16线及32线都行），已经在launch中给出配置的launch文件
![这是图片](pictures/model01.png "shinshe")
### 1.2、gmapping建图仅支持二维雷达
### 1.3、二维建图保存与读取
需提前在robot_simulation/launch/map_save.launch其中设定好保存的名字与路径
``roslaunch robot_simulation map_save.launch``

## 2、使用说明
基于ros noetic版本桌面完整版，用launch文件一键启动，如刷新当前环境变量``source ./devel/set.bash``：启动搭载16线三维雷达（velodyne）的麦轮小车：
```
roslaunch robot_simulation VLP16_car.launch

```
### 2.1、搭载HDL-32三维雷达的麦轮仿真
启动：``roslaunch robot_simulation HDL32_car.launch``
### 2.2、搭载VLP-16三维雷达的麦轮仿真
启动：``roslaunch robot_simulation VLP16_car.launch``
### 2.3、搭载二维雷达的麦轮仿真
启动：``roslaunch robot_simulation 2D_lidar_car.launch``
二维雷达不同，可以用ros自带的开源包，amcl提供定位，movebase提供导航，在launch文件中默认已经开了
## 3、依赖
其中对于三维机械式雷达（velodyne）的仿真,其提供了与ros的接口转换，需要安装相关的velodyne仿真插件：
```
sudo apt-get install ros-noetic-velodyne
sudo apt-get install ros-noetic-velodyne*

```
## 4、接口
仿真给出的接口:
1. /cmd_vel 控制机器人运动的接口，其接收消息格式为``geometry_msgs/Twist``,包含
```
geometry_msgs/Vector3 linear
  float64 x
  float64 y
  float64 z
geometry_msgs/Vector3 angular
  float64 x
  float64 y
  float64 z
```
``geometry_msgs/Vector3 angular``为欧拉角控制，angular z为yaw角控制
2. /odom gazebo提供发布的odom里程计，应该是精确的，发布实时定位消息,格式为nav_msgs/Odometry,具体包含有效信息如下
```
std_msgs/Header header
  uint32 seq
  time stamp
  string frame_id
string child_frame_id
geometry_msgs/PoseWithCovariance pose
  geometry_msgs/Pose pose
    geometry_msgs/Point position
      float64 x
      float64 y
      float64 z
    geometry_msgs/Quaternion orientation
      float64 x
      float64 y
      float64 z
      float64 w
  float64[36] covariance
geometry_msgs/TwistWithCovariance twist
  geometry_msgs/Twist twist
    geometry_msgs/Vector3 linear
      float64 x
      float64 y
      float64 z
    geometry_msgs/Vector3 angular
      float64 x
      float64 y
      float64 z
  float64[36] covariance
```
