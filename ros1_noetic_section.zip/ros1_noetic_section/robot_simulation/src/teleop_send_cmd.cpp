#include <geometry_msgs/Twist.h>
#include <ros/ros.h>
#include <ros/console.h>
#include <unistd.h>
#include <tf/transform_broadcaster.h>
#include "std_msgs/String.h" //普通文本类型的消息
#include <geometry_msgs/PointStamped.h>

#include <iostream>
#include <termios.h>
class control
{
    public:
        control(ros::NodeHandle& nh);//
        ~control();
        
        void set_moving();
        void keyboard_watchig_callback(const std_msgs::String::ConstPtr& msg);

        char keyboard_input;
        char last_input;
        geometry_msgs::Vector3 my_linear;
        geometry_msgs::Vector3 my_angular;
        geometry_msgs::Twist my_twist;
        float kp;
        float x;
        float y;
        float angular_v;
        ros::Publisher cmd_pub;
        
};

control::control(ros::NodeHandle& nh)
{
    cmd_pub= nh.advertise<geometry_msgs::Twist>("cmd_vel", 1, true);

    keyboard_input='s';//不动
    kp=0.4;x=0;y=0;angular_v=0;
}

control::~control()
{
    
}
void control::keyboard_watchig_callback(const std_msgs::String::ConstPtr& msg)
{   
    keyboard_input=msg->data.c_str()[0];
}

void control::set_moving() 
{   //首次获取the_way容器里对象的索引
    
    
    bool fail_key_flag=false;
    switch (keyboard_input)
    {//反方向抑制
    case '1':   kp=0.4;break;
    case '2':   kp=0.7;break;
    case '3':   kp=1.0;break;
    case '4':   kp=1.3;break;
    case '5':   kp=1.5;break;
    case '6':   kp=1.7;break;
    case 'q':   x=1.1;y=1.1;break;
    case 'w':   x=1.1;y=0;break;
    case 'e':   x=1;y=-1;break;
    case 'a':   x=0;y=1.1;break;            
    case 's':   x=0;y=0;fail_key_flag=true;break;
    case 'd':   x=0;y=-1;break;
    case 'z':   x=-1.1;y=1.1;break;
    case 'c':   x=-1;y=-1;break;
    case 'x':   x=-1;y=0;break;
    case 'j':   x=0;y=0;angular_v=0.4;break;
    case 'k':   angular_v=0;break;
    case 'l':   x=0;y=0;angular_v=-0.4;break;
    default:    ROS_INFO("输入无效");fail_key_flag=true;break;
    }
    if(last_input!=keyboard_input)
    {
        ROS_INFO("输入方向: %c",keyboard_input);//自我接收显示
        last_input=keyboard_input;
    }
    my_twist.linear.x=x*kp;
    my_twist.linear.y=y*kp;
    my_twist.linear.z=0;
    my_twist.angular.x=0;
    my_twist.angular.y=0;
    my_twist.angular.z=angular_v;//angular.z=0;//直行   =-0.5;//+逆时针转圈
    if(!fail_key_flag)
    cmd_pub.publish(my_twist);
}

int main(int argc,char** argv)
{   
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "moving_control_by_cmd");
    ros::NodeHandle nh;

    control moving(nh);
    
    ros::Subscriber keyboard_watching = nh.subscribe<std_msgs::String>("keyboard_input",100,&control::keyboard_watchig_callback,&moving);

    ROS_INFO("一个手写的键盘控制节点：");
    ROS_INFO("键入档位决定速度如: 1、2、3、4、5、6");
    ROS_INFO("键入方向指行"); ROS_INFO("键入j、k、l旋转车体");


    ros::Rate r(250);
    
    while(ros::ok)
    {   
        
        moving.set_moving();
        r.sleep();
        ros::spinOnce();
    }
    return 0;
}



