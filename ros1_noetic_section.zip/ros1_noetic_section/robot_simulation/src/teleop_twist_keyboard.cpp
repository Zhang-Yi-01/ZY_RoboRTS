#include <iostream>
#include <ros/ros.h>
#include <termios.h>
#include "std_msgs/String.h" //普通文本类型的消息
#include <sstream> 

int ScanKeyboard()
{
	int in;
 
	struct termios new_settings;
	struct termios stored_settings;
    //设置终端参数
	tcgetattr(0,&stored_settings);
	new_settings = stored_settings;
	new_settings.c_lflag &= (~ICANON);
	new_settings.c_cc[VTIME] = 0;
	tcgetattr(0,&stored_settings);
	new_settings.c_cc[VMIN] = 1;
	tcsetattr(0,TCSANOW,&new_settings);
	in = getchar();
	tcsetattr(0,TCSANOW,&stored_settings);

	return in;
 
}

int main(int argc,char** argv)
{   
    setlocale(LC_ALL,"");
    ros::init(argc, argv, "keyboard_watching_node");
    ros::NodeHandle nh;
    ros::Publisher input_pub= nh.advertise<std_msgs::String>("keyboard_input", 1, true);
    

    std_msgs::String msg;
    ros::Rate r(100);
    
    while(ros::ok)
    {   
        char temp=(char)ScanKeyboard();
        ROS_INFO("towards %c",temp);
        std::stringstream ss;
        ss <<temp;
        msg.data = ss.str();
        input_pub.publish(msg);
    }
    return 0;
}

