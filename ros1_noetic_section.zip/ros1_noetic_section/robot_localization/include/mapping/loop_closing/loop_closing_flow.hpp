/*
 * @Description: 回环检测任务管理器
 * @Author: ZY
 * @Date: 2022.10.24
 */